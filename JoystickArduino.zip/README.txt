Just double click on the jar and upload the sketch to the arduino.
Plug in a 180 degree servo into DIO 9.
You're ready to go!

note: do NOT take the jar out of the zip: it requires the dlls to be in the same location.